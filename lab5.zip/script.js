let events = [];
function addEvent() {
    let eventName = document.getElementById("event").value;
 if (eventName == "") {
        alert("enter an event name.");
        return;
}
    if (events.length >= 3) {
        alert("3 events max.");
  return;
}
    events.push(eventName);
 alert("Event added");
 document.getElementById("output").innerHTML =
        "Added Events: " + events.join(", ");
    document.getElementById("event").value = "";
}
function confirmRegistration() {
    let studentName = document.getElementById("studentName").value;
    if (studentName == "") {
        alert("Please enter your student name.");
        return;
 }
    if (events.length == 0) {
        alert("Please add an event.");
return;
 }
    localStorage.setItem("studentName", studentName);
    localStorage.setItem("events", JSON.stringify(events));
    window.location.href = "confirm.html";
}