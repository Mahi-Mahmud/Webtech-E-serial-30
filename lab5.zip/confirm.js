let studentName = localStorage.getItem("studentName");
let events = JSON.parse(localStorage.getItem("events"));
if (events == null) {
    events = [];
}
let output = document.getElementById("output");
if (studentName == null || events.length == 0) {
    output.innerHTML = "No registration found.";
} 
else {
    output.innerHTML = "<h2>Registration Successful</h2>";
    output.innerHTML += "Student Name: " + studentName;
    output.innerHTML += "<h3>Registered events:</h3>";
    for (let i = 0; i < events.length; i++) {
        output.innerHTML += events[i] + "<br>";
    }
    output.innerHTML += "<h3>Total Fee: " +
        (events.length * 150) + " Taka</h3>";
}